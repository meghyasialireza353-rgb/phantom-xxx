# Changelog

## 1.1.5 (WARP build)
- The sing-box core is now built during the build (official v1.11.4 source, Go), so Shadowsocks, Hysteria2, TUIC, Trojan,
  VLESS (incl. Reality) and VMess links connect. It needs Go 1.23.1+ on the build machine (GitHub's ubuntu runners have it).

## 1.1.4 (WARP build)
- AI advisor card on the home screen (Google Gemini): suggests protocols, WireGuard settings and fixes for slow
  connections. The key is built into the app (gradle.properties) and cannot be viewed or changed in the app.
  Texts that contain configs, share links or keys are never sent.
- `withWarp=true` is now set in gradle.properties, so any build of this zip includes WireGuard, WARP and the extra protocols.

## Unreleased (WARP build)
- Live traffic chart on the home screen (download green, upload cyan, last 60 s) for every connection type:
  Phantom X, WARP, WireGuard and the share-link protocols.
- Bypass Iranian apps now applies to every tunnel (Phantom X, WARP, WireGuard, share-link protocols) from the one
  Settings switch (on by default): Iranian apps go direct, foreign apps stay on the VPN.
- WireGuard: full client in the Extra tunnels card. Multiple encrypted profiles; import from .conf file, clipboard,
  `wireguard://` link or QR picture; key management (public key, generate/rotate key pair, preshared key);
  live status (endpoint, uptime, last handshake, traffic and speed) with a notification and Disconnect button;
  automatic diagnostics and recovery (endpoint fallbacks, MTU fallback, dead-tunnel and network-switch reconnect).
- Extra tunnels: Shadowsocks, Hysteria2, TUIC, Trojan, VLESS, VMess from share links (sing-box core).

## 1.1.3
- Fast IPv6 fallback (Settings > Advanced, on by default): no IPv6 address on the tunnel, so apps like Telegram fall back to IPv4 at once.
- A stream that dies while opening is retried once; apps wait up to 10 s for a tunnel that is reconnecting.
- Faster re-dial after the tunnel is declared unhealthy; idle connections stay open for 20 minutes.
- Recent logs section on the home screen.

## 1.1.2
- Bypass Iranian apps: package prefix `ir.`, well-known Iranian packages, bank/payment names, Persian-labelled user apps.

## 1.1.0
- Tools card: speed test, fastest server, copy exit IP.

## 1.0.8
- Creator badge.
- Faster dead-link detection (keep-alive), a 403 for one destination no longer invalidates the whole session,
  shorter refusal cache, larger relay buffer.
