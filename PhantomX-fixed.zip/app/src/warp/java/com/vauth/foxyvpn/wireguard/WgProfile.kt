package com.vauth.foxyvpn.wireguard

import kotlinx.serialization.Serializable

@Serializable
data class WgProfile(
    val id: String,
    val name: String,
    /** Full config text (contains the private key, only ever stored encrypted). */
    val config: String,
    /** Extra endpoints (host:port, one per entry) tried in order when the main one does not answer. */
    val fallbackEndpoints: List<String> = emptyList(),
    /** Adds PersistentKeepalive = 25 when the config has none, so the tunnel survives NAT and starts at once. */
    val autoKeepalive: Boolean = true,
    /** Lets installed Iranian apps skip this tunnel (same detection as the main VPN). */
    val bypassIranianApps: Boolean = false,
    val createdAt: Long = 0L,
    val lastConnectedAt: Long = 0L,
    /** The endpoint that answered last time; tried first for a fast reconnect. */
    val lastGoodEndpoint: String? = null,
    /** MTU that passed the traffic check last time (only used when the config has no MTU of its own). */
    val lastGoodMtu: Int? = null,
)
