package com.vauth.foxyvpn.wireguard

import android.content.Context
import com.wireguard.android.backend.GoBackend

/**
 * One shared GoBackend for the whole process. GoBackend keeps the "current tunnel" in the instance, so the
 * WARP tunnel and the WireGuard profiles must use the same object: bringing one up then takes the other down
 * cleanly instead of leaving two engines fighting over the VPN interface.
 */
object WgBackend {
    @Volatile
    private var instance: GoBackend? = null

    fun get(context: Context): GoBackend =
        instance ?: synchronized(this) {
            instance ?: GoBackend(context.applicationContext).also { instance = it }
        }
}
