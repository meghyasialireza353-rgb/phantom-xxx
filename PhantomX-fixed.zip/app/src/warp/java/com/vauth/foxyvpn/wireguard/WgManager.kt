package com.vauth.foxyvpn.wireguard

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.SystemClock
import com.vauth.foxyvpn.data.AppLogger
import com.vauth.foxyvpn.vpn.IranianApps
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

enum class WgState { IDLE, CONNECTING, CONNECTED, RECONNECTING, FAILED }

data class WgStats(
    val rx: Long = 0,
    val tx: Long = 0,
    val rxRate: Long = 0,
    val txRate: Long = 0,
    /** Seconds since the last handshake, null before the first one. */
    val handshakeAgeSec: Long? = null,
    val connectedSince: Long = 0,
)

data class WgUi(
    val state: WgState = WgState.IDLE,
    val message: String = "Not connected",
    val profileId: String? = null,
    val profileName: String? = null,
    val endpoint: String? = null,
    val stats: WgStats = WgStats(),
    val diagnostics: List<DiagItem> = emptyList(),
    val diagnosing: Boolean = false,
)

data class WgValidation(val items: List<DiagItem>, val publicKey: String?) {
    val hasErrors: Boolean get() = items.any { it.level == DiagLevel.ERROR }
}

/**
 * WireGuard profiles on top of the official wireguard-go backend.
 *
 * Connect: parse and check the config, try the endpoint (last working one first, then the configured one,
 * its other IP addresses, then your fallbacks), wait for a real handshake, verify that traffic passes and
 * lower the MTU if large packets are lost. While connected a monitor reads the statistics every second,
 * detects a dead tunnel or a network switch and reconnects by itself.
 */
object WgManager {
    private const val TAG = "WireGuard"
    private const val DEFAULT_MTU = 1420
    private const val SAFE_MTU = 1280
    private val RECOVERY_BACKOFF_MS = longArrayOf(1_000, 4_000, 10_000)

    @Volatile private var appContext: Context? = null

    /** Last line of defence: an unexpected error must end in a clean "failed" state, never in a crash. */
    private val guard = CoroutineExceptionHandler { _, t ->
        AppLogger.e(TAG, "unexpected error", t)
        appContext?.let { setDown(WgBackend.get(it)) }
        monitorJob?.cancel()
        _ui.update { it.copy(state = WgState.FAILED, message = "Unexpected error: ${t.message ?: t.javaClass.simpleName}", stats = WgStats()) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO + guard)
    private val lock = Mutex()
    private val session = AtomicLong(0)

    private val _ui = MutableStateFlow(WgUi())
    val ui: StateFlow<WgUi> = _ui.asStateFlow()

    @Volatile private var job: Job? = null
    @Volatile private var monitorJob: Job? = null
    @Volatile private var internalChange = false

    private val tunnel = object : Tunnel {
        override fun getName(): String = "phantomwg"

        override fun onStateChange(newState: Tunnel.State) {
            if (newState == Tunnel.State.DOWN) onTunnelDown()
        }
    }

    private inline fun upd(my: Long, f: (WgUi) -> WgUi) {
        if (session.get() == my) _ui.update { f(it) }
    }

    /** The tunnel went down without us asking: another VPN (or WARP) took the interface. */
    private fun onTunnelDown() {
        if (internalChange) return
        val st = _ui.value.state
        if (st == WgState.IDLE || st == WgState.FAILED) return
        session.incrementAndGet()
        job?.cancel()
        monitorJob?.cancel()
        AppLogger.i(TAG, "tunnel stopped by the system or another VPN")
        _ui.update { WgUi(WgState.IDLE, "Disconnected (another VPN took over)", it.profileId, it.profileName) }
    }

    // ---------------------------------------------------------------- public API

    fun connect(context: Context, profileId: String) {
        val app = context.applicationContext
        appContext = app
        val profile = WgProfileStore.get(profileId)
        if (profile == null) {
            _ui.value = WgUi(WgState.FAILED, "Profile not found")
            return
        }
        val my = session.incrementAndGet()
        job?.cancel()
        monitorJob?.cancel()
        _ui.value = WgUi(WgState.CONNECTING, "Preparing\u2026", profile.id, profile.name)
        startService(app)
        job = scope.launch {
            lock.withLock {
                val ok = runConnect(app, profile, my, recovery = false)
                if (!ok) {
                    setDown(WgBackend.get(app))
                }
            }
        }
    }

    fun disconnect(context: Context) {
        val app = context.applicationContext
        session.incrementAndGet()
        job?.cancel()
        monitorJob?.cancel()
        _ui.update { WgUi(WgState.IDLE, "Disconnected", it.profileId, it.profileName) }
        scope.launch { lock.withLock { setDown(WgBackend.get(app)) } }
        AppLogger.i(TAG, "disconnected")
    }

    fun validate(raw: String): WgValidation {
        val text = WgConfigText.parse(raw)
        return try {
            val cfg = Config.parse(text.toText().byteInputStream())
            WgValidation(WgDiagnostics.staticChecks(text, cfg), WgKeys.publicKeyOf(text))
        } catch (e: BadConfigException) {
            WgValidation(listOf(WgDiagnostics.explain(e)), WgKeys.publicKeyOf(text))
        } catch (e: IOException) {
            WgValidation(listOf(DiagItem(DiagLevel.ERROR, "Config could not be read", e.message.orEmpty())), null)
        }
    }

    /** Manual "run diagnostics": offline checks always, live traffic checks when the tunnel is up. */
    fun diagnose(context: Context, profileId: String?) {
        val app = context.applicationContext
        val st = _ui.value
        if (st.diagnosing) return
        _ui.update { it.copy(diagnosing = true) }
        scope.launch {
            val items = mutableListOf<DiagItem>()
            val profile = WgProfileStore.get(profileId ?: st.profileId)
            if (profile != null) {
                items += validate(profile.config).items
                val parsed = WgConfigText.parse(profile.config)
                val host = parsed.peers.firstOrNull()?.get("Endpoint")?.let { splitHostPort(it)?.first }
                if (host != null && !isLiteral(host)) {
                    val addrs = WgDiagnostics.resolve(host)
                    items += if (addrs.isEmpty()) DiagItem(
                        DiagLevel.ERROR, "Endpoint host does not resolve", host,
                        "Check the spelling, your DNS, or use the server's IP address.",
                    ) else DiagItem(DiagLevel.OK, "Endpoint resolves", addrs.joinToString(", ") { it.hostAddress.orEmpty() })
                }
            }
            if (!WgDiagnostics.hasUnderlyingNetwork(app)) {
                items += DiagItem(DiagLevel.ERROR, "No internet connection", "The device has no usable network.", "Turn on Wi-Fi or mobile data.")
            } else {
                items += DiagItem(DiagLevel.OK, "Device is online")
            }
            if (st.state == WgState.CONNECTED) {
                val s = readStats(WgBackend.get(app))
                if (s != null && s.handshakeMs > 0) {
                    val age = (System.currentTimeMillis() - s.handshakeMs) / 1000
                    items += DiagItem(DiagLevel.OK, "Handshake ${age}s ago", "Received ${s.rx} B, sent ${s.tx} B.")
                } else {
                    items += DiagItem(DiagLevel.ERROR, "No handshake", "", "The server is not answering; see the fixes above.")
                }
                items += WgDiagnostics.probeTunnel(app).items
            }
            _ui.update { it.copy(diagnostics = items, diagnosing = false) }
        }
    }

    // ---------------------------------------------------------------- connect flow

    private fun prepare(app: Context, profile: WgProfile, source: WgConfigText): WgConfigText {
        val t = source.copy()
        val iface = t.iface
        if (iface != null) {
            if (!iface.has("MTU")) iface.set("MTU", (profile.lastGoodMtu ?: DEFAULT_MTU).toString())
            if ((profile.bypassIranianApps || IranianApps.enabled(app)) && !iface.has("ExcludedApplications") && !iface.has("IncludedApplications")) {
                val apps = IranianApps.find(app)
                if (apps.isNotEmpty()) iface.set("ExcludedApplications", apps.sorted().joinToString(", "))
            }
        }
        if (profile.autoKeepalive) {
            for (p in t.peers) if (!p.has("PersistentKeepalive") && p.has("Endpoint")) p.set("PersistentKeepalive", "25")
        }
        return t
    }

    private fun makeConfig(base: WgConfigText, endpoint: String?, mtu: Int?): Config {
        val t = base.copy()
        if (endpoint != null) t.peers.firstOrNull()?.set("Endpoint", endpoint)
        if (mtu != null) t.iface?.set("MTU", mtu.toString())
        return Config.parse(t.toText().byteInputStream())
    }

    private suspend fun runConnect(app: Context, profile: WgProfile, my: Long, recovery: Boolean): Boolean {
        val be = WgBackend.get(app)
        val diag = mutableListOf<DiagItem>()
        val progress = if (recovery) WgState.RECONNECTING else WgState.CONNECTING

        fun say(message: String) = upd(my) { it.copy(state = progress, message = message, diagnostics = diag.toList()) }
        fun fail(message: String): Boolean {
            if (!recovery) failState(my, message, diag)
            else upd(my) { it.copy(diagnostics = diag.toList()) }
            return false
        }

        say(if (recovery) "Reconnecting\u2026" else "Checking the config\u2026")

        val source = WgConfigText.parse(profile.config)
        val base = prepare(app, profile, source)
        val firstCfg = try {
            Config.parse(base.toText().byteInputStream())
        } catch (e: BadConfigException) {
            diag += WgDiagnostics.explain(e)
            return fail("The config has an error")
        } catch (e: IOException) {
            diag += DiagItem(DiagLevel.ERROR, "Config could not be read", e.message.orEmpty())
            return fail("The config could not be read")
        }
        if (!recovery) {
            diag += WgDiagnostics.staticChecks(source, firstCfg)
            if (diag.any { it.level == DiagLevel.ERROR }) return fail("Fix the config first")
        }

        // The device must be online. After a network switch we give it a few seconds to come back.
        var waited = 0
        while (!WgDiagnostics.hasUnderlyingNetwork(app)) {
            if (!recovery || waited >= 20) {
                diag += DiagItem(DiagLevel.ERROR, "No internet connection", "The device has no usable network.", "Turn on Wi-Fi or mobile data and try again.")
                return fail("No internet connection")
            }
            say("Waiting for the network\u2026")
            delay(1000)
            waited++
            currentCoroutineContext().ensureActive()
        }

        // Endpoint candidates: last working, configured, other IPs of the host, then the user's fallbacks.
        val single = base.peers.singleOrNull()
        val candidates = mutableListOf<String?>()
        val configured = single?.get("Endpoint")
        if (single != null && configured != null) {
            profile.lastGoodEndpoint?.let { candidates += it }
            candidates += configured
            val hp = splitHostPort(configured)
            if (hp != null && !isLiteral(hp.first)) {
                val addrs = WgDiagnostics.resolve(hp.first)
                if (addrs.isEmpty()) {
                    diag += DiagItem(
                        DiagLevel.WARN, "Endpoint host does not resolve", hp.first,
                        "Check the spelling, or put the server's IP address in Endpoint.",
                    )
                } else {
                    addrs.filterIsInstance<Inet4Address>().take(2).forEach { candidates += "${it.hostAddress}:${hp.second}" }
                }
            }
            candidates += profile.fallbackEndpoints.map { it.trim() }.filter { it.isNotEmpty() }
        } else {
            candidates += null
        }
        val unique = candidates.distinct().take(6)
        if (unique.size == 1 && unique[0] != null && splitHostPort(unique[0]!!)?.first?.let { !isLiteral(it) } == true &&
            diag.any { it.title.startsWith("Endpoint host does not resolve") }
        ) {
            diag += WgDiagnostics.explainBackend("DNS_RESOLUTION_FAILURE", null)
            return fail("The server name cannot be resolved")
        }

        // Bring the tunnel up on each candidate until the server answers with a handshake.
        val tried = mutableListOf<String>()
        var cfgUsed: Config? = null
        var endpointUsed: String? = null
        var abort = false
        val baseMtu = base.iface?.get("MTU")?.toIntOrNull()
        for ((index, cand) in unique.withIndex()) {
            currentCoroutineContext().ensureActive()
            if (session.get() != my) return false
            val label = cand ?: "configured endpoint"
            tried += label
            say(if (unique.size > 1) "Connecting\u2026 ($label, ${index + 1}/${unique.size})" else "Connecting\u2026")
            val cfg = try {
                makeConfig(base, cand, null)
            } catch (e: BadConfigException) {
                diag += DiagItem(DiagLevel.WARN, "Endpoint \"$label\" is not valid", "", "Use the form host:port.")
                continue
            } catch (e: IOException) {
                continue
            }
            val problem = bringUp(be, cfg)
            if (problem != null) {
                diag += problem.first
                if (problem.second != "DNS_RESOLUTION_FAILURE") {
                    abort = true
                    break
                }
                continue
            }
            val ok = awaitHandshake(be, if (index == 0) 10_000 else 7_000, nudgeTarget(cfg), my)
            if (ok) {
                cfgUsed = cfg
                endpointUsed = cand ?: configured
                break
            }
            setDown(be)
        }
        if (cfgUsed == null) {
            if (!abort) diag += WgDiagnostics.noHandshakeAdvice(tried)
            return fail(if (abort) "The tunnel could not start" else "The server did not answer")
        }

        // Traffic check (only meaningful when everything is routed through the tunnel).
        var mtuUsed = baseMtu
        var message = "Connected"
        var degraded = false
        if (WgDiagnostics.isFullTunnel(cfgUsed)) {
            say("Verifying the connection\u2026")
            var probe = WgDiagnostics.probeTunnel(app)
            val current = mtuUsed ?: DEFAULT_MTU
            if (probe.ipOk && !probe.httpsOk && current > SAFE_MTU && source.iface?.has("MTU") != true) {
                say("Lowering MTU to $SAFE_MTU\u2026")
                diag += DiagItem(DiagLevel.INFO, "MTU lowered to $SAFE_MTU", "Large packets were lost at $current, so the tunnel was restarted with a smaller MTU.")
                setDown(be)
                val retry = try {
                    makeConfig(base, endpointUsed.takeIf { it != configured }, SAFE_MTU)
                } catch (e: Exception) {
                    null
                }
                if (retry != null && bringUp(be, retry) == null &&
                    awaitHandshake(be, 8_000, nudgeTarget(retry), my)
                ) {
                    cfgUsed = retry
                    mtuUsed = SAFE_MTU
                    probe = WgDiagnostics.probeTunnel(app)
                } else {
                    // Could not restart with the smaller MTU: go back to what worked for the handshake.
                    setDown(be)
                    val back = makeConfig(base, endpointUsed.takeIf { it != configured }, null)
                    if (bringUp(be, back) == null && awaitHandshake(be, 8_000, nudgeTarget(back), my)) cfgUsed = back
                    else return fail("The tunnel could not be restarted")
                }
            }
            diag += probe.items
            if (!probe.ipOk) {
                degraded = true
                message = "Connected, but no traffic passes (see diagnostics)"
            } else if (!probe.dnsOk) {
                message = "Connected (DNS is not answering)"
            }
        }
        if (session.get() != my) return false

        val now = System.currentTimeMillis()
        val keptSince = _ui.value.stats.connectedSince
        val remembered = if (source.iface?.has("MTU") == true) null else mtuUsed
        WgProfileStore.markConnected(profile.id, endpointUsed, if (degraded) null else remembered)
        AppLogger.i(TAG, "connected via ${endpointUsed ?: "configured endpoint"}" + (mtuUsed?.let { ", MTU $it" } ?: ""))
        upd(my) {
            it.copy(
                state = WgState.CONNECTED,
                message = message,
                profileId = profile.id,
                profileName = profile.name,
                endpoint = endpointUsed,
                stats = WgStats(connectedSince = if (recovery && keptSince > 0) keptSince else now),
                diagnostics = diag.toList(),
            )
        }
        startMonitor(app, profile.id, cfgUsed, my)
        return true
    }

    /** Returns null on success, or the explanation plus the backend reason code. */
    private fun bringUp(be: GoBackend, cfg: Config): Pair<DiagItem, String?>? {
        internalChange = true
        return try {
            be.setState(tunnel, Tunnel.State.UP, cfg)
            null
        } catch (e: BackendException) {
            val reason = runCatching { e.reason.name }.getOrNull()
            AppLogger.w(TAG, "backend refused to start: $reason")
            WgDiagnostics.explainBackend(reason, e.message) to reason
        } catch (t: Throwable) {
            AppLogger.w(TAG, "backend error", t)
            WgDiagnostics.explainBackend(null, t.message ?: t.javaClass.simpleName) to null
        } finally {
            internalChange = false
        }
    }

    private fun setDown(be: GoBackend) {
        internalChange = true
        try {
            be.setState(tunnel, Tunnel.State.DOWN, null)
        } catch (t: Throwable) {
            AppLogger.w(TAG, "error stopping the tunnel", t)
        } finally {
            internalChange = false
        }
    }

    private fun failState(my: Long, message: String, diag: List<DiagItem>) {
        if (session.get() != my) return
        AppLogger.w(TAG, message)
        _ui.update { it.copy(state = WgState.FAILED, message = message, stats = WgStats(), diagnostics = diag.toList()) }
    }

    private class Sample(val rx: Long, val tx: Long, val handshakeMs: Long)

    private fun readStats(be: GoBackend): Sample? = try {
        val s = be.getStatistics(tunnel)
        var hs = 0L
        for (k in s.peers()) {
            val p = s.peer(k) ?: continue
            val h = p.latestHandshakeEpochMillis()
            if (h > hs) hs = h
        }
        Sample(s.totalRx(), s.totalTx(), hs)
    } catch (t: Throwable) {
        null
    }

    private suspend fun awaitHandshake(be: GoBackend, timeoutMs: Long, nudgeTo: InetAddress?, my: Long): Boolean {
        val start = SystemClock.elapsedRealtime()
        var nudges = 0
        while (true) {
            if ((readStats(be)?.handshakeMs ?: 0L) > 0L) return true
            val elapsed = SystemClock.elapsedRealtime() - start
            if (elapsed >= timeoutMs || session.get() != my) return false
            // Traffic makes WireGuard start the handshake at once; a tiny DNS query is enough.
            if (nudgeTo != null && nudges < 3 && elapsed >= nudges * 2_000L) {
                sendDnsNudge(nudgeTo)
                nudges++
            }
            delay(250)
        }
    }

    // ---------------------------------------------------------------- monitor and recovery

    private fun startMonitor(app: Context, profileId: String, cfg: Config, my: Long) {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            val be = WgBackend.get(app)
            val watcher = NetWatcher(app)
            val target = nudgeTarget(cfg)
            // Without keepalive an idle tunnel legitimately never re-keys, so the handshake age says nothing.
            val keepalive = cfg.getPeers().any { it.persistentKeepalive.isPresent }
            val window = ArrayDeque<Sample2>()
            var prev: Sample2? = null
            var stalled = 0
            var phase = 0
            var t1 = 0L
            var t2 = 0L
            var rxMark = 0L
            try {
                while (isActive && session.get() == my) {
                    delay(1000)
                    val s = readStats(be)
                    if (s == null) {
                        continue
                    }
                    val now = SystemClock.elapsedRealtime()
                    val cur = Sample2(now, s.rx, s.tx)
                    val p = prev
                    val dt = if (p != null) (now - p.t).coerceAtLeast(1) else 1000L
                    val rxRate = if (p != null) (s.rx - p.rx).coerceAtLeast(0) * 1000 / dt else 0L
                    val txRate = if (p != null) (s.tx - p.tx).coerceAtLeast(0) * 1000 / dt else 0L
                    prev = cur
                    window.addLast(cur)
                    while (window.isNotEmpty() && now - window.first().t > 25_000) window.removeFirst()
                    val age = if (s.handshakeMs > 0) ((System.currentTimeMillis() - s.handshakeMs) / 1000).coerceAtLeast(0) else null
                    upd(my) { ui -> ui.copy(stats = ui.stats.copy(rx = s.rx, tx = s.tx, rxRate = rxRate, txRate = txRate, handshakeAgeSec = age)) }

                    // 1) The tunnel stopped working: lots of outgoing data and nothing coming back,
                    //    or no handshake for far longer than WireGuard's re-key interval.
                    val span = now - window.first().t
                    val rx25 = s.rx - window.first().rx
                    val tx25 = s.tx - window.first().tx
                    val dead = (keepalive && age != null && age > 200) || (span >= 20_000 && tx25 > 4096 && rx25 == 0L)
                    stalled = if (dead) stalled + 1 else 0
                    if (stalled >= 3) {
                        AppLogger.w(TAG, "tunnel looks dead (handshake age ${age}s, tx $tx25 B, rx $rx25 B)")
                        recover(app, profileId, my, "The connection stopped answering")
                        return@launch
                    }

                    // 2) The phone switched networks (Wi-Fi <-> mobile): check that data still flows.
                    if (watcher.consume()) {
                        phase = 1
                        t1 = now + 2_500
                        rxMark = s.rx
                    }
                    if (phase == 1 && now >= t1) {
                        if (target != null) {
                            sendDnsNudge(target)
                            phase = 2
                            t2 = now + 6_000
                        } else {
                            phase = 0
                        }
                    } else if (phase == 2 && now >= t2) {
                        phase = 0
                        if (s.rx <= rxMark) {
                            AppLogger.w(TAG, "no data after a network change")
                            recover(app, profileId, my, "The network changed")
                            return@launch
                        }
                    }
                }
            } finally {
                watcher.close()
            }
        }
    }

    private class Sample2(val t: Long, val rx: Long, val tx: Long)

    private fun recover(app: Context, profileId: String, my: Long, reason: String) {
        job = scope.launch {
            val profile = WgProfileStore.get(profileId)
            if (profile == null) {
                failState(my, "Profile was removed", emptyList())
                return@launch
            }
            for (attempt in 1..RECOVERY_BACKOFF_MS.size) {
                if (session.get() != my) return@launch
                upd(my) { it.copy(state = WgState.RECONNECTING, message = "$reason \u2013 reconnecting ($attempt/${RECOVERY_BACKOFF_MS.size})\u2026") }
                AppLogger.i(TAG, "reconnect attempt $attempt: $reason")
                delay(RECOVERY_BACKOFF_MS[attempt - 1])
                val ok = lock.withLock {
                    if (session.get() != my) return@withLock false
                    setDown(WgBackend.get(app))
                    runConnect(app, profile, my, recovery = true)
                }
                if (ok) return@launch
            }
            if (session.get() == my) {
                lock.withLock { setDown(WgBackend.get(app)) }
                _ui.update { it.copy(state = WgState.FAILED, message = "Connection lost and could not be restored", stats = WgStats()) }
                AppLogger.w(TAG, "gave up reconnecting")
            }
        }
    }

    /** Reports changes of the real (non-VPN) networks so the monitor can check the tunnel after a switch. */
    private class NetWatcher(context: Context) {
        private val cm = context.getSystemService(ConnectivityManager::class.java)
        private val changed = AtomicBoolean(false)
        private val startedAt = SystemClock.elapsedRealtime()
        private val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                mark()
            }

            override fun onLost(network: Network) {
                mark()
            }

            private fun mark() {
                // Android replays the current networks right after registering; ignore that burst.
                if (SystemClock.elapsedRealtime() - startedAt > 3_000) changed.set(true)
            }
        }

        init {
            runCatching {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                    .build()
                cm.registerNetworkCallback(request, callback)
            }
        }

        fun consume(): Boolean = changed.getAndSet(false)

        fun close() {
            runCatching { cm.unregisterNetworkCallback(callback) }
        }
    }

    // ---------------------------------------------------------------- helpers

    /** An address inside the tunnel that answers a DNS query: the tunnel DNS server, or 1.1.1.1 for a full tunnel. */
    private fun nudgeTarget(cfg: Config): InetAddress? {
        val dns = cfg.getInterface().dnsServers.firstOrNull { it.address.size == 4 && WgDiagnostics.isRouted(cfg, it) }
        if (dns != null) return dns
        val cloudflare = InetAddress.getByAddress(byteArrayOf(1, 1, 1, 1))
        return if (WgDiagnostics.isRouted(cfg, cloudflare)) cloudflare else null
    }

    private fun sendDnsNudge(target: InetAddress) {
        runCatching {
            val packet = dnsQuery()
            DatagramSocket().use { it.send(DatagramPacket(packet, packet.size, target, 53)) }
        }
    }

    private fun dnsQuery(): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0))
        for (label in "cloudflare.com".split('.')) {
            out.write(label.length)
            out.write(label.toByteArray())
        }
        out.write(0)
        out.write(byteArrayOf(0, 1, 0, 1))
        return out.toByteArray()
    }

    private fun isLiteral(host: String): Boolean =
        host.contains(':') || host.all { it.isDigit() || it == '.' }

    /** "host:port" or "[v6]:port" -> (host, port). */
    private fun splitHostPort(value: String): Pair<String, String>? {
        val v = value.trim()
        if (v.startsWith("[")) {
            val end = v.indexOf(']')
            if (end < 0) return null
            val port = v.substring(end + 1).removePrefix(":")
            return v.substring(1, end) to port.ifEmpty { "51820" }
        }
        val i = v.lastIndexOf(':')
        if (i <= 0) return null
        return v.substring(0, i) to v.substring(i + 1)
    }

    private fun startService(app: Context) {
        runCatching { app.startForegroundService(Intent(app, WgMonitorService::class.java)) }
            .onFailure { AppLogger.w(TAG, "could not start the status notification", it) }
    }
}
