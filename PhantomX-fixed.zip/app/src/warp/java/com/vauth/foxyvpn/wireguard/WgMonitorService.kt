package com.vauth.foxyvpn.wireguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.vauth.foxyvpn.data.formatBytes
import com.vauth.foxyvpn.data.formatBytesPerSecond
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Foreground notification for the WireGuard tunnel. It keeps the process alive in the background and shows
 * live status with a Disconnect button. The tunnel itself runs in the WireGuard backend, not here.
 */
class WgMonitorService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "WireGuard", NotificationManager.IMPORTANCE_LOW))
        // Must be promoted within seconds of startForegroundService().
        ServiceCompat.startForeground(this, NOTIF_ID, build(WgManager.ui.value), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        if (intent?.action == ACTION_STOP) {
            WgManager.disconnect(applicationContext)
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }

        scope.launch {
            WgManager.ui
                .map { Triple(it.state, it.message, it.stats.rx / 4096 + it.stats.tx / 4096) }
                .distinctUntilChanged()
                .collect {
                    val ui = WgManager.ui.value
                    if (ui.state == WgState.IDLE || ui.state == WgState.FAILED) {
                        ServiceCompat.stopForeground(this@WgMonitorService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                        stopSelf()
                    } else {
                        nm.notify(NOTIF_ID, build(ui))
                    }
                }
        }
        return START_NOT_STICKY
    }

    private fun build(ui: WgUi): Notification {
        val title = "WireGuard \u2022 ${ui.profileName ?: "tunnel"}"
        val text = when (ui.state) {
            WgState.CONNECTED -> "\u2193 ${formatBytesPerSecond(ui.stats.rxRate)}  \u2191 ${formatBytesPerSecond(ui.stats.txRate)}  \u2022 total ${formatBytes(ui.stats.rx + ui.stats.tx)}"
            else -> ui.message
        }
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, WgMonitorService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", stop).build())
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.alireza.phantomx.wireguard.STOP"
        private const val CHANNEL = "phantom_wg"
        private const val NOTIF_ID = 4218
    }
}
