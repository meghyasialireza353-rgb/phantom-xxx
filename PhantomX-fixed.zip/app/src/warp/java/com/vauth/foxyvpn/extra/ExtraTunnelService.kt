package com.vauth.foxyvpn.extra

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.vauth.foxyvpn.data.AppLogger
import com.vauth.foxyvpn.vpn.IranianApps
import com.vauth.foxyvpn.vpn.tun.HevSocks5Tunnel
import com.vauth.foxyvpn.vpn.tun.HevSocks5TunnelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.ServerSocket
import java.net.Socket
import java.net.URL

/**
 * TUN -> hev-socks5-tunnel -> local SOCKS5 (sing-box core) -> remote server.
 * The core runs as a child process of this app; the app is excluded from the VPN, so the core's own
 * sockets reach the server directly without protect() calls.
 */
class ExtraTunnelService : VpnService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var tun: ParcelFileDescriptor? = null
    private var core: Process? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground()
        if (intent?.action == ACTION_STOP) {
            teardown("Disconnected", ExtraStatus.IDLE)
            stopSelf()
            return START_NOT_STICKY
        }
        val profile = ExtraTunnelManager.pending
        if (profile == null) {
            teardown("Nothing to connect", ExtraStatus.FAILED)
            stopSelf()
            return START_NOT_STICKY
        }
        job?.cancel()
        job = scope.launch { connect(profile) }
        return START_NOT_STICKY
    }

    private fun startForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Extra tunnel", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Phantom X extra tunnel")
            .setContentText("Connected")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
            .build()
        startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
    }

    private suspend fun connect(profile: ProxyProfile) {
        try {
            val bin = File(applicationInfo.nativeLibraryDir, "libsingbox.so")
            if (!bin.exists()) {
                fail("The tunnel core is not included for this device (${android.os.Build.SUPPORTED_ABIS.firstOrNull()}).")
                return
            }
            val port = ServerSocket(0).use { it.localPort }
            val dir = File(filesDir, "singbox").apply { mkdirs() }
            val cfg = File(dir, "config.json").apply { writeText(profile.toSingBoxConfig(port)) }

            val pb = ProcessBuilder(bin.absolutePath, "run", "-c", cfg.absolutePath, "-D", dir.absolutePath)
                .redirectErrorStream(true)
            // Go does not know Android's certificate directory when built as a plain Linux binary.
            pb.environment()["SSL_CERT_DIR"] = "/system/etc/security/cacerts"
            val p = pb.start()
            core = p
            scope.launch {
                p.inputStream.bufferedReader().forEachLine { AppLogger.i(TAG, it.take(300)) }
            }

            if (!waitForPort(port, p)) {
                fail("The core did not start. Check the link.")
                return
            }

            val iranianApps = IranianApps.forTunnel(this)
            val fd = Builder()
                .setSession("Phantom X extra")
                .addAddress(HevSocks5TunnelConfig.TUN_ADDRESS, 32)
                .addRoute("0.0.0.0", 0)
                .addDnsServer(HevSocks5TunnelConfig.MAPDNS_ADDRESS)
                .setMtu(HevSocks5TunnelConfig.TUN_MTU)
                .setBlocking(true)
                .apply {
                    runCatching { addDisallowedApplication(packageName) }
                    // Iranian apps (banks, payment, taxi...) skip the tunnel; a missing package is ignored.
                    for (pkg in iranianApps) runCatching { addDisallowedApplication(pkg) }
                }
                .establish()
            if (fd == null) {
                fail("VPN permission was not granted")
                return
            }
            tun = fd
            val cfgPath = HevSocks5TunnelConfig.write(this, port)
            if (!HevSocks5Tunnel.start(cfgPath, fd.fd)) {
                fail("Could not start the packet forwarder")
                return
            }

            if (!probe(port)) {
                fail("${profile.kind} server did not answer. Check the link or try another network.")
                return
            }
            AppLogger.i(TAG, "${profile.kind} connected")
            ExtraTunnelManager.set(ExtraStatus.CONNECTED, "Connected via ${profile.kind} \u2022 ${profile.name}")
        } catch (t: Throwable) {
            AppLogger.e(TAG, "connect failed", t)
            fail("Failed: ${t.message ?: t.javaClass.simpleName}")
        }
    }

    private suspend fun waitForPort(port: Int, p: Process): Boolean {
        repeat(40) {
            if (!p.isAlive) return false
            val ok = runCatching { Socket().use { it.connect(InetSocketAddress("127.0.0.1", port), 200) } }.isSuccess
            if (ok) return true
            delay(200)
        }
        return false
    }

    /** One real request through the local SOCKS5 port proves the remote server works. */
    private fun probe(port: Int): Boolean = runCatching {
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", port))
        val c = URL("http://cp.cloudflare.com/generate_204").openConnection(proxy) as java.net.HttpURLConnection
        c.connectTimeout = 10_000
        c.readTimeout = 10_000
        c.responseCode in 200..399
    }.getOrDefault(false)

    private fun fail(message: String) {
        AppLogger.w(TAG, message)
        teardown(message, ExtraStatus.FAILED)
        stopSelf()
    }

    private fun release() {
        job?.cancel()
        runCatching { HevSocks5Tunnel.stop() }
        runCatching { core?.destroy() }
        core = null
        runCatching { tun?.close() }
        tun = null
    }

    private fun teardown(message: String, status: ExtraStatus) {
        release()
        ExtraTunnelManager.set(status, message)
    }

    override fun onRevoke() {
        teardown("Another VPN took over", ExtraStatus.IDLE)
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        release()
        val st = ExtraTunnelManager.ui.value.status
        if (st == ExtraStatus.CONNECTED || st == ExtraStatus.WORKING) {
            ExtraTunnelManager.set(ExtraStatus.IDLE, "Disconnected")
        }
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.alireza.phantomx.extra.STOP"
        private const val TAG = "ExtraTunnel"
        private const val CHANNEL = "phantom_extra"
        private const val NOTIF_ID = 4217
    }
}
