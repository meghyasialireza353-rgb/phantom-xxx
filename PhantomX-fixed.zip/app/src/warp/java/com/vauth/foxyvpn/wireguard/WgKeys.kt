package com.vauth.foxyvpn.wireguard

import com.wireguard.crypto.Key
import com.wireguard.crypto.KeyPair
import java.security.SecureRandom

/** Key helpers. Private keys never leave this object except as the strings the caller asked for. */
object WgKeys {
    data class Generated(val privateKey: String, val publicKey: String)

    fun generate(): Generated {
        val kp = KeyPair()
        return Generated(kp.privateKey.toBase64(), kp.publicKey.toBase64())
    }

    fun publicFromPrivate(privateKey: String): String? =
        runCatching { KeyPair(Key.fromBase64(privateKey.trim())).publicKey.toBase64() }.getOrNull()

    fun generatePresharedKey(): String {
        val bytes = ByteArray(32)
        SecureRandom().nextBytes(bytes)
        return Key.fromBytes(bytes).toBase64()
    }

    fun isValid(key: String): Boolean = runCatching { Key.fromBase64(key.trim()) }.isSuccess

    /** "AbCd…xYz=" style preview that is safe to show or log. */
    fun mask(key: String): String {
        val k = key.trim()
        return if (k.length <= 8) "••••" else k.take(4) + "…" + k.takeLast(3)
    }

    /** Public key that matches the private key in [text], or null when it is missing or invalid. */
    fun publicKeyOf(text: WgConfigText): String? =
        text.iface?.get("PrivateKey")?.let { publicFromPrivate(it) }

    /** Replaces the private key in [config] with a fresh one and returns the new text together with the new public key. */
    fun rotatePrivateKey(config: String): Pair<String, String> {
        val parsed = WgConfigText.parse(config)
        var iface = parsed.iface
        if (iface == null) {
            iface = WgSection("Interface")
            parsed.sections.add(0, iface)
        }
        val fresh = generate()
        iface.set("PrivateKey", fresh.privateKey)
        return Pair(parsed.toText(), fresh.publicKey)
    }

    /** Sets, replaces or removes the PresharedKey of the first peer. */
    fun setPresharedKey(config: String, key: String?): String {
        val parsed = WgConfigText.parse(config)
        val peer = parsed.peers.firstOrNull() ?: return config
        if (key == null) peer.remove("PresharedKey") else peer.set("PresharedKey", key)
        return parsed.toText()
    }
}
