package com.vauth.foxyvpn.ui

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.extra.ExtraStatus
import com.vauth.foxyvpn.extra.ExtraTunnelManager

/**
 * Shadowsocks, Hysteria2, TUIC, Trojan, VLESS and VMess from a pasted share link.
 * Shown inside the "Extra tunnels" card of the WARP build.
 */
@Composable
fun ExtraProtocolsSection() {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val ui by ExtraTunnelManager.ui.collectAsState()
    var link by remember { mutableStateOf(ExtraTunnelManager.savedLink(context)) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            ExtraTunnelManager.start(context, link)
        } else {
            ExtraTunnelManager.set(ExtraStatus.FAILED, "VPN permission was not granted")
        }
    }

    fun start() {
        val intent = VpnService.prepare(context)
        if (intent == null) ExtraTunnelManager.start(context, link) else launcher.launch(intent)
    }

    val working = ui.status == ExtraStatus.WORKING
    val connected = ui.status == ExtraStatus.CONNECTED

    Spacer(Modifier.height(8.dp))
    Text(
        "Shadowsocks \u2022 Hysteria2 \u2022 TUIC \u2022 Trojan \u2022 VLESS \u2022 VMess",
        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
    )
    Text(ui.message, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))
    OutlinedTextField(
        value = link,
        onValueChange = { link = it },
        modifier = Modifier.fillMaxWidth(),
        minLines = 2,
        maxLines = 4,
        placeholder = { Text("ss://\u2026  hysteria2://\u2026  trojan://\u2026  vless://\u2026") },
    )
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        TextButton(onClick = { link = readClipboard(context) }) { Text("Paste") }
        Spacer(Modifier.weight(1f))
        if (working) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
        } else {
            FilledTonalButton(
                onClick = { if (connected) ExtraTunnelManager.stop(context) else start() },
                enabled = connected || link.isNotBlank(),
            ) { Text(if (connected) "Disconnect" else "Connect") }
        }
    }
}

private fun readClipboard(context: Context): String {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    return cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim().orEmpty()
}
