package com.vauth.foxyvpn.wireguard

import java.util.Locale

/**
 * Small editable model of a WireGuard config file.
 *
 * The Android WireGuard library is strict (unknown keys such as PostUp or Table make it throw), while configs
 * exported by desktop tools often contain them. This model reads the text leniently, remembers what had to
 * be ignored, lets the app change single values (endpoint, MTU, keepalive, keys) and writes clean text back.
 */
class WgSection(val name: String) {
    val entries: MutableList<Pair<String, String>> = mutableListOf()

    fun get(key: String): String? =
        entries.firstOrNull { it.first.equals(key, ignoreCase = true) }?.second

    fun has(key: String): Boolean = get(key) != null

    fun set(key: String, value: String) {
        val index = entries.indexOfFirst { it.first.equals(key, ignoreCase = true) }
        if (index >= 0) entries[index] = key to value else entries.add(key to value)
    }

    fun remove(key: String) {
        entries.removeAll { it.first.equals(key, ignoreCase = true) }
    }
}

class WgConfigText private constructor(
    val sections: MutableList<WgSection>,
    /** Human readable notes about lines that were ignored while reading. */
    val notes: List<String>,
) {
    val iface: WgSection? get() = sections.firstOrNull { it.name.equals("Interface", ignoreCase = true) }

    val peers: List<WgSection> get() = sections.filter { it.name.equals("Peer", ignoreCase = true) }

    fun copy(): WgConfigText {
        val cloned = sections.map { s -> WgSection(s.name).also { it.entries.addAll(s.entries) } }
        return WgConfigText(cloned.toMutableList(), notes)
    }

    fun toText(): String = buildString {
        for (section in sections) {
            if (section.name.isNotEmpty()) append('[').append(section.name).append("]\n")
            for ((k, v) in section.entries) append(k).append(" = ").append(v).append('\n')
            append('\n')
        }
    }.trimEnd() + "\n"

    companion object {
        /** Options that wg-quick understands but the Android library rejects. They only run shell commands or routing tweaks. */
        private val UNSUPPORTED = setOf("preup", "postup", "predown", "postdown", "table", "saveconfig", "fwmark")

        fun parse(raw: String): WgConfigText {
            val notes = mutableListOf<String>()
            val sections = mutableListOf<WgSection>()
            var current: WgSection? = null
            val text = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
            for (rawLine in text.split('\n')) {
                val hash = rawLine.indexOf('#')
                val line = (if (hash >= 0) rawLine.substring(0, hash) else rawLine).trim()
                if (line.isEmpty()) continue
                if (line.startsWith("[") && line.endsWith("]")) {
                    val name = line.substring(1, line.length - 1).trim()
                    val canonical = when (name.lowercase(Locale.ROOT)) {
                        "interface" -> "Interface"
                        "peer" -> "Peer"
                        else -> name
                    }
                    current = WgSection(canonical).also { sections.add(it) }
                    continue
                }
                val eq = line.indexOf('=')
                if (eq <= 0) {
                    // Keep the line so the strict parser can report a precise syntax error.
                    val s = current ?: WgSection("").also { sections.add(it); current = it }
                    s.entries.add(line to "")
                    continue
                }
                val key = line.substring(0, eq).trim()
                val value = line.substring(eq + 1).trim()
                if (key.lowercase(Locale.ROOT) in UNSUPPORTED) {
                    notes.add("Ignored \"$key\" (not supported on Android)")
                    continue
                }
                val s = current ?: WgSection("").also { sections.add(it); current = it }
                s.entries.add(key to value)
            }
            return WgConfigText(sections, notes)
        }

        /**
         * Reads share links of the form
         * wireguard://PRIVATEKEY@host:port?publickey=...&address=...&mtu=...&presharedkey=...&dns=...#name
         * and returns a normal config text plus a suggested name, or null when [link] is not such a link.
         */
        fun fromLink(link: String): Pair<String, String>? {
            val trimmed = link.trim()
            val lower = trimmed.lowercase(Locale.ROOT)
            val scheme = listOf("wireguard://", "wg://").firstOrNull { lower.startsWith(it) } ?: return null
            var rest = trimmed.substring(scheme.length)
            var name = ""
            val fragmentAt = rest.indexOf('#')
            if (fragmentAt >= 0) {
                name = pctDecode(rest.substring(fragmentAt + 1))
                rest = rest.substring(0, fragmentAt)
            }
            var query = ""
            val queryAt = rest.indexOf('?')
            if (queryAt >= 0) {
                query = rest.substring(queryAt + 1)
                rest = rest.substring(0, queryAt)
            }
            val at = rest.lastIndexOf('@')
            if (at <= 0) return null
            val privateKey = pctDecode(rest.substring(0, at))
            var hostPort = rest.substring(at + 1).trimEnd('/')
            if (hostPort.isEmpty()) return null
            val params = HashMap<String, String>()
            for (pair in query.split('&')) {
                val i = pair.indexOf('=')
                if (i > 0) params[pair.substring(0, i).lowercase(Locale.ROOT)] = pctDecode(pair.substring(i + 1))
            }
            val publicKey = params["publickey"] ?: params["public_key"] ?: return null
            val address = params["address"] ?: params["ip"] ?: return null
            if (!hostPort.startsWith("[") && !hostPort.contains(':')) hostPort += ":51820"
            val section = StringBuilder()
            section.append("[Interface]\n")
            section.append("PrivateKey = ").append(privateKey).append('\n')
            section.append("Address = ").append(address).append('\n')
            params["dns"]?.let { section.append("DNS = ").append(it).append('\n') }
            params["mtu"]?.let { section.append("MTU = ").append(it).append('\n') }
            section.append("\n[Peer]\n")
            section.append("PublicKey = ").append(publicKey).append('\n')
            (params["presharedkey"] ?: params["psk"])?.let { section.append("PresharedKey = ").append(it).append('\n') }
            section.append("AllowedIPs = ").append(params["allowedips"] ?: "0.0.0.0/0, ::/0").append('\n')
            section.append("Endpoint = ").append(hostPort).append('\n')
            (params["keepalive"] ?: params["persistentkeepalive"])?.let {
                section.append("PersistentKeepalive = ").append(it).append('\n')
            }
            return section.toString() to name.ifBlank { hostPort.substringBefore(':').trim('[', ']') }
        }

        /** Percent decoding that leaves '+' alone (base64 keys contain it). */
        private fun pctDecode(s: String): String {
            if (!s.contains('%')) return s
            val out = java.io.ByteArrayOutputStream()
            var i = 0
            val bytes = s.toByteArray(Charsets.UTF_8)
            while (i < bytes.size) {
                val c = bytes[i].toInt().toChar()
                if (c == '%' && i + 2 < bytes.size) {
                    val hex = String(bytes, i + 1, 2, Charsets.US_ASCII)
                    val v = hex.toIntOrNull(16)
                    if (v != null) {
                        out.write(v)
                        i += 3
                        continue
                    }
                }
                out.write(bytes[i].toInt())
                i++
            }
            return String(out.toByteArray(), Charsets.UTF_8)
        }
    }
}
