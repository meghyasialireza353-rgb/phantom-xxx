package com.vauth.foxyvpn.extra

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.URI
import java.net.URLDecoder

/** A proxy server parsed from a share link (ss://, hysteria2://, trojan://, vless://, vmess://, tuic://). */
data class ProxyProfile(val kind: String, val name: String, val outbound: JSONObject) {

    /** Complete sing-box config: local SOCKS5 inbound -> this outbound. */
    fun toSingBoxConfig(socksPort: Int): String {
        val proxy = JSONObject(outbound.toString()).put("tag", "proxy")
        val root = JSONObject()
            .put("log", JSONObject().put("level", "warn").put("timestamp", false))
            .put(
                "dns",
                JSONObject()
                    .put("servers", JSONArray().put(JSONObject().put("tag", "d").put("address", "1.1.1.1")))
                    .put("strategy", "ipv4_only"),
            )
            .put(
                "inbounds",
                JSONArray().put(
                    JSONObject()
                        .put("type", "socks").put("tag", "in")
                        .put("listen", "127.0.0.1").put("listen_port", socksPort),
                ),
            )
            .put(
                "outbounds",
                JSONArray().put(proxy).put(JSONObject().put("type", "direct").put("tag", "direct")),
            )
            .put("route", JSONObject().put("final", "proxy").put("auto_detect_interface", false))
        return root.toString()
    }

    companion object {
        fun parse(raw: String): ProxyProfile {
            val link = raw.trim()
            val scheme = link.substringBefore("://", "").lowercase()
            return when (scheme) {
                "ss" -> shadowsocks(link)
                "hysteria2", "hy2" -> hysteria2(link)
                "trojan" -> trojan(link)
                "vless" -> vless(link)
                "vmess" -> vmess(link)
                "tuic" -> tuic(link)
                else -> error("Unsupported link. Use ss://, hysteria2://, trojan://, vless://, vmess:// or tuic://")
            }
        }

        private fun q(u: URI): Map<String, String> =
            (u.rawQuery ?: "").split('&').filter { it.contains('=') }.associate {
                URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8")
            }

        private fun name(u: URI, fallback: String) =
            u.rawFragment?.let { URLDecoder.decode(it, "UTF-8") }?.takeIf { it.isNotBlank() } ?: fallback

        private fun b64(s: String): String {
            val flags = Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP
            return String(Base64.decode(s.replace('+', '-').replace('/', '_').trimEnd('='), flags))
        }

        private fun tls(sni: String?, host: String, p: Map<String, String>, alpn: List<String>? = null): JSONObject {
            val t = JSONObject().put("enabled", true).put("server_name", sni?.takeIf { it.isNotBlank() } ?: host)
            if (p["insecure"] == "1" || p["allowInsecure"] == "1") t.put("insecure", true)
            alpn?.let { t.put("alpn", JSONArray(it)) }
            p["fp"]?.takeIf { it.isNotBlank() }?.let {
                t.put("utls", JSONObject().put("enabled", true).put("fingerprint", it))
            }
            return t
        }

        private fun server(type: String, host: String, port: Int) =
            JSONObject().put("type", type).put("server", host).put("server_port", port)

        private fun shadowsocks(link: String): ProxyProfile {
            val body = link.removePrefix("ss://")
            val frag = body.substringAfter('#', "")
            var main = body.substringBefore('#').substringBefore('?')
            if (!main.contains('@')) main = b64(main)
            val at = main.lastIndexOf('@')
            var userInfo = main.substring(0, at)
            if (!userInfo.contains(':')) userInfo = b64(userInfo)
            val hostPort = main.substring(at + 1).trimEnd('/')
            val method = userInfo.substringBefore(':')
            val password = userInfo.substringAfter(':')
            val host = hostPort.substringBeforeLast(':').trim('[', ']')
            val port = hostPort.substringAfterLast(':').toInt()
            val o = server("shadowsocks", host, port).put("method", method).put("password", password)
            return ProxyProfile("Shadowsocks", URLDecoder.decode(frag, "UTF-8").ifBlank { host }, o)
        }

        private fun hysteria2(link: String): ProxyProfile {
            val u = URI(link.replaceFirst("hy2://", "hysteria2://"))
            val p = q(u)
            val o = server("hysteria2", u.host, if (u.port > 0) u.port else 443)
                .put("password", URLDecoder.decode(u.rawUserInfo ?: "", "UTF-8"))
                .put("tls", tls(p["sni"], u.host, p, listOf("h3")))
            if (!p["obfs"].isNullOrBlank()) {
                o.put("obfs", JSONObject().put("type", p["obfs"]).put("password", p["obfs-password"] ?: ""))
            }
            // Bandwidth is left unset on purpose: sing-box then uses BBR, which is faster and safer than a fixed Brutal rate.
            p["upmbps"]?.toIntOrNull()?.let { o.put("up_mbps", it) }
            p["downmbps"]?.toIntOrNull()?.let { o.put("down_mbps", it) }
            return ProxyProfile("Hysteria2", name(u, u.host), o)
        }

        private fun trojan(link: String): ProxyProfile {
            val u = URI(link)
            val p = q(u)
            val o = server("trojan", u.host, if (u.port > 0) u.port else 443)
                .put("password", URLDecoder.decode(u.rawUserInfo ?: "", "UTF-8"))
                .put("tls", tls(p["sni"] ?: p["peer"], u.host, p))
            transport(p)?.let { o.put("transport", it) }
            return ProxyProfile("Trojan", name(u, u.host), o)
        }

        private fun vless(link: String): ProxyProfile {
            val u = URI(link)
            val p = q(u)
            val o = server("vless", u.host, if (u.port > 0) u.port else 443)
                .put("uuid", u.rawUserInfo ?: "")
            p["flow"]?.takeIf { it.isNotBlank() }?.let { o.put("flow", it) }
            when (p["security"]) {
                "tls" -> o.put("tls", tls(p["sni"], u.host, p))
                "reality" -> o.put(
                    "tls",
                    tls(p["sni"], u.host, p.toMutableMap().apply { putIfAbsent("fp", "chrome") }).put(
                        "reality",
                        JSONObject().put("enabled", true)
                            .put("public_key", p["pbk"] ?: "").put("short_id", p["sid"] ?: ""),
                    ),
                )
            }
            transport(p)?.let { o.put("transport", it) }
            return ProxyProfile("VLESS", name(u, u.host), o)
        }

        private fun vmess(link: String): ProxyProfile {
            val j = JSONObject(b64(link.removePrefix("vmess://").trim()))
            val host = j.getString("add")
            val o = server("vmess", host, j.get("port").toString().toInt())
                .put("uuid", j.getString("id"))
                .put("security", j.optString("scy", "auto").ifBlank { "auto" })
                .put("alter_id", j.optString("aid", "0").toIntOrNull() ?: 0)
            val p = mutableMapOf(
                "type" to j.optString("net", "tcp"),
                "path" to j.optString("path", ""),
                "host" to j.optString("host", ""),
                "serviceName" to j.optString("path", ""),
            )
            if (j.optString("tls") == "tls") o.put("tls", tls(j.optString("sni"), host, p))
            transport(p)?.let { o.put("transport", it) }
            return ProxyProfile("VMess", j.optString("ps", host).ifBlank { host }, o)
        }

        private fun tuic(link: String): ProxyProfile {
            val u = URI(link)
            val p = q(u)
            val info = (u.rawUserInfo ?: "").split(':', limit = 2)
            val o = server("tuic", u.host, if (u.port > 0) u.port else 443)
                .put("uuid", info[0])
                .put("password", info.getOrElse(1) { "" })
                .put("congestion_control", p["congestion_control"] ?: "bbr")
                .put("tls", tls(p["sni"], u.host, p, (p["alpn"] ?: "h3").split(',')))
            return ProxyProfile("TUIC", name(u, u.host), o)
        }

        private fun transport(p: Map<String, String>): JSONObject? = when (p["type"]) {
            "ws" -> JSONObject().put("type", "ws").put("path", p["path"] ?: "/")
                .apply { p["host"]?.takeIf { it.isNotBlank() }?.let { put("headers", JSONObject().put("Host", it)) } }
            "grpc" -> JSONObject().put("type", "grpc").put("service_name", p["serviceName"] ?: "")
            "http", "h2" -> JSONObject().put("type", "http").put("path", p["path"] ?: "/")
            else -> null
        }
    }
}
