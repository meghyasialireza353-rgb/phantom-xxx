package com.vauth.foxyvpn.ui

import android.app.Activity
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.warp.WarpManager
import com.vauth.foxyvpn.warp.WarpStatus
import kotlinx.coroutines.launch

/**
 * Optional extra tunnels: free Cloudflare WARP (registered automatically), full WireGuard profiles
 * (see [WireGuardSection]) and share-link protocols. Connecting one replaces the normal Phantom X VPN until you reconnect it.
 */
@Composable
fun WarpCard(modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val ui by WarpManager.ui.collectAsState()

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            scope.launch { WarpManager.connect(context, null) }
        } else {
            WarpManager.fail("VPN permission was not granted")
        }
    }

    fun start() {
        val intent = VpnService.prepare(context)
        if (intent == null) {
            scope.launch { WarpManager.connect(context, null) }
        } else {
            launcher.launch(intent)
        }
    }

    val working = ui.status == WarpStatus.WORKING
    val connected = ui.status == WarpStatus.CONNECTED

    Column(
        modifier = modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surfaceContainer)
            .padding(18.dp),
    ) {
        Text("Extra tunnels", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "Cloudflare WARP",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                )
                Text(ui.message, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
            }
            if (working) {
                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
            } else {
                FilledTonalButton(
                    onClick = {
                        if (connected) {
                            scope.launch { WarpManager.disconnect() }
                        } else {
                            start()
                        }
                    },
                ) {
                    Text(if (connected) "Disconnect" else "Connect")
                }
            }
        }

        WireGuardSection()

        ExtraProtocolsSection()

        Spacer(Modifier.height(8.dp))
        Text(
            "Connecting here replaces the Phantom X VPN. If WARP can't register, connect Phantom X first, register, then disconnect.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
}
