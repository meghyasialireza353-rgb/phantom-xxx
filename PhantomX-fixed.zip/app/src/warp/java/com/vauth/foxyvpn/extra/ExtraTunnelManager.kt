package com.vauth.foxyvpn.extra

import android.content.Context
import android.content.Intent
import com.vauth.foxyvpn.data.AppLogger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ExtraStatus { IDLE, WORKING, CONNECTED, FAILED }

data class ExtraUi(val status: ExtraStatus, val message: String)

/** UI-facing state for the sing-box based tunnels (Shadowsocks, Hysteria2, Trojan, VLESS, VMess, TUIC). */
object ExtraTunnelManager {
    private const val TAG = "ExtraTunnel"
    private const val PREFS = "phantom_extra"

    private val _ui = MutableStateFlow(ExtraUi(ExtraStatus.IDLE, "Paste a server link to connect"))
    val ui: StateFlow<ExtraUi> = _ui.asStateFlow()

    @Volatile
    internal var pending: ProxyProfile? = null

    fun set(status: ExtraStatus, message: String) {
        _ui.value = ExtraUi(status, message)
    }

    fun savedLink(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("link", "") ?: ""

    fun start(context: Context, link: String) {
        val profile = try {
            ProxyProfile.parse(link)
        } catch (t: Throwable) {
            set(ExtraStatus.FAILED, t.message ?: "Invalid link")
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("link", link.trim()).apply()
        pending = profile
        AppLogger.i(TAG, "starting ${profile.kind} (${profile.name})")
        set(ExtraStatus.WORKING, "Starting ${profile.kind}\u2026")
        context.startForegroundService(Intent(context, ExtraTunnelService::class.java))
    }

    fun stop(context: Context) {
        context.startService(Intent(context, ExtraTunnelService::class.java).setAction(ExtraTunnelService.ACTION_STOP))
    }
}
