package com.vauth.foxyvpn.vpn

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import com.vauth.foxyvpn.data.AppLogger
import com.vauth.foxyvpn.data.SettingsStore

/**
 * Finds installed Iranian apps (banks, payment, taxi, shopping, messengers, ...) so they can skip
 * the VPN automatically and keep working normally while the tunnel is on.
 *
 * There is no list of "Iranian apps" on the device, so an app counts when any of these is true:
 *  - its package name starts with `ir.` (the usual prefix of Iranian developers),
 *  - it is one of the well-known Iranian packages below,
 *  - its package name or label looks like a bank / payment app,
 *  - it is a user-installed app whose label is written in Persian script (never Google, system
 *    or well-known international apps, whose labels are localised on Persian phones).
 */
object IranianApps {

    private const val TAG = "IranianApps"

    private val KNOWN_PACKAGES = setOf(
        "cab.snapp.passenger",
        "cab.snapp.driver",
        "cab.snapp.snappfood",
        "taxi.tap30.passenger",
        "taxi.tap30.driver",
        "com.farsitel.bazaar",
        "ir.mservices.market",
        "com.digikala",
        "ir.divar",
        "com.sheypoor.mobile",
        "ir.eitaa.messenger",
        "ir.resaneh1.iptv",
        "ir.nasim",
        "ir.soroush.messenger",
        "ir.balad",
        "org.neshan",
        "ir.mci.ecareapp",
        "ir.alibaba",
    )

    private val PACKAGE_PREFIXES = listOf("ir.")

    private val BANK_PACKAGE_KEYWORDS = listOf(
        "bank", "mellat", "melli", "saderat", "sepah", "pasargad", "refah", "tejarat",
        "maskan", "parsian", "ayandeh", "keshavarzi", "karafarin", "asanpardakht",
    )

    // بانک ، bank ، پرداخت
    private val BANK_LABEL_KEYWORDS = listOf("\u0628\u0627\u0646\u06A9", "bank", "\u067E\u0631\u062F\u0627\u062E\u062A")

    // بام، سپ، آپ، تاپ
    private val BANK_LABEL_EXACT = setOf(
        "\u0628\u0627\u0645", "\u0633\u067E", "\u0622\u067E", "\u062A\u0627\u067E",
    )

    private val NEVER_BY_LABEL_PREFIXES = listOf(
        "com.google.", "com.android.", "com.samsung.", "com.sec.", "com.miui.", "com.xiaomi.",
        "com.huawei.", "com.oppo.", "com.coloros.", "com.vivo.", "com.microsoft.",
        "org.telegram.", "org.thunderdog.", "com.instagram.", "com.whatsapp", "com.twitter.",
        "com.facebook.", "com.zhiliaoapp.", "com.discord", "com.spotify.",
    )

    /** True unless the user switched "Bypass Iranian apps" off in Settings (it is on by default). */
    fun enabled(context: Context): Boolean =
        runCatching { SettingsStore(context.applicationContext).autoBypassIranianApps }.getOrDefault(true)

    /**
     * Iranian apps that must skip a tunnel, or an empty set when the setting is off.
     * Used by every tunnel (Phantom X, WARP, WireGuard, share-link protocols). Never throws.
     */
    fun forTunnel(context: Context): Set<String> =
        runCatching { if (enabled(context)) find(context) else emptySet() }.getOrDefault(emptySet())

    fun find(context: Context): Set<String> {
        val pm = context.packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = runCatching { pm.queryIntentActivities(launcherIntent, 0) }
            .getOrElse { return emptySet() }
        val found = HashSet<String>()
        for (info in apps) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (pkg == context.packageName) continue
            val label = runCatching { info.loadLabel(pm).toString() }.getOrDefault("")
            val isSystem = (info.activityInfo?.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM != 0
            if (isIranian(pkg, label, isSystem)) found.add(pkg)
        }
        if (found.isNotEmpty()) AppLogger.i(TAG, "bypassing VPN for ${found.size} Iranian app(s)")
        return found
    }

    private fun isIranian(packageName: String, label: String, isSystem: Boolean): Boolean {
        val p = packageName.lowercase()
        val l = label.trim().lowercase()
        if (p in KNOWN_PACKAGES) return true
        if (PACKAGE_PREFIXES.any { p.startsWith(it) }) return true
        if (BANK_PACKAGE_KEYWORDS.any { p.contains(it) }) return true
        if (BANK_LABEL_KEYWORDS.any { l.contains(it) } || l in BANK_LABEL_EXACT) return true
        if (!isSystem && hasPersianLetters(l) && NEVER_BY_LABEL_PREFIXES.none { p.startsWith(it) }) return true
        return false
    }

    private fun hasPersianLetters(text: String): Boolean = text.any { it in '\u0600'..'\u06FF' }
}
