package com.vauth.foxyvpn.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.InetSocketAddress
import java.net.Proxy
import java.util.concurrent.TimeUnit

private const val LATENCY_URL = "https://www.cloudflare.com/cdn-cgi/trace"
private const val DOWNLOAD_URL = "https://speed.cloudflare.com/__down?bytes=8000000"

data class SpeedTestResult(
    val downloadMbps: Double,
    val latencyMs: Long,
)

/**
 * Measures the tunnel the same way the exit check does: by going through the local SOCKS5
 * proxy, so the numbers describe the VPN path and not the phone's direct connection.
 */
object SpeedTest {

    suspend fun run(socksPort: Int): Result<SpeedTestResult> = withContext(Dispatchers.IO) {
        val proxy = Proxy(Proxy.Type.SOCKS, InetSocketAddress("127.0.0.1", socksPort))
        val client = OkHttpClient.Builder()
            .proxy(proxy)
            .connectTimeout(12, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            .build()
        try {
            runCatching {
                val latencyStart = System.nanoTime()
                client.newCall(Request.Builder().url(LATENCY_URL).build()).execute().use { response ->
                    if (!response.isSuccessful) error("Latency probe failed: HTTP ${response.code}")
                    response.body?.bytes()
                }
                val latencyMs = (System.nanoTime() - latencyStart) / 1_000_000L

                val downloadStart = System.nanoTime()
                var totalBytes = 0L
                client.newCall(Request.Builder().url(DOWNLOAD_URL).build()).execute().use { response ->
                    if (!response.isSuccessful) error("Download probe failed: HTTP ${response.code}")
                    val body = response.body ?: error("Download probe returned no data")
                    val buffer = ByteArray(64 * 1024)
                    body.byteStream().use { stream ->
                        while (true) {
                            val read = stream.read(buffer)
                            if (read < 0) break
                            totalBytes += read
                        }
                    }
                }
                val seconds = ((System.nanoTime() - downloadStart) / 1_000_000_000.0).coerceAtLeast(0.001)
                SpeedTestResult(
                    downloadMbps = totalBytes * 8.0 / 1_000_000.0 / seconds,
                    latencyMs = latencyMs,
                )
            }
        } finally {
            client.dispatcher.executorService.shutdown()
            client.connectionPool.evictAll()
        }
    }
}
