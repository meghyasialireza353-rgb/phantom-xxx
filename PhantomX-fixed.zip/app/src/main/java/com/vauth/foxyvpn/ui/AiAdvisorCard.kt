package com.vauth.foxyvpn.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.ai.GeminiAdvisor
import kotlinx.coroutines.launch

private val QUICK_QUESTIONS = listOf(
    "Which protocol is best for me?" to
        "Which protocol should I use in a country with heavy filtering and unstable mobile internet: WireGuard, VLESS Reality, Hysteria2, Trojan or Shadowsocks? Compare them briefly and give a ranking.",
    "Best WireGuard settings" to
        "What are the best WireGuard client settings on Android for stability and speed (MTU, keepalive, endpoint port, DNS)? Explain each one simply.",
    "Fix slow speed" to
        "My VPN connects but is slow or drops often. Give me a step-by-step checklist to find and fix the cause.",
    "Best config tips" to
        "How do I choose a good VPN config or server (location, port, transport, Reality vs TLS)? Give practical rules of thumb.",
)

/** Card with a built-in AI advisor. The key is part of the build and cannot be changed in the app. */
@Composable
fun AiAdvisorCard(modifier: Modifier = Modifier) {
    if (!GeminiAdvisor.available) return

    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun ask(q: String) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            when (val r = GeminiAdvisor.ask(q)) {
                is GeminiAdvisor.Result.Ok -> answer = r.text
                is GeminiAdvisor.Result.Fail -> error = r.message
            }
            busy = false
        }
    }

    Column(
        modifier = modifier
            .padding(bottom = 12.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(scheme.surfaceContainer)
            .padding(18.dp),
    ) {
        Text("AI advisor", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        Spacer(Modifier.height(4.dp))
        Text(
            "Ask about the best protocols, configs and settings.",
            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        )
        Spacer(Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            QUICK_QUESTIONS.forEach { (label, prompt) ->
                AssistChip(
                    onClick = { question = label; ask(prompt) },
                    label = { Text(label) },
                    enabled = !busy,
                )
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = question,
            onValueChange = { question = it },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask anything about VPN setup") },
            minLines = 2,
            maxLines = 5,
            enabled = !busy,
        )
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End,
        ) {
            if (busy) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
            }
            FilledTonalButton(onClick = { ask(question) }, enabled = !busy && question.isNotBlank()) {
                Text("Ask")
            }
        }

        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, style = MaterialTheme.typography.bodySmall, color = scheme.error)
        }
        answer?.let {
            Spacer(Modifier.height(10.dp))
            SelectionContainer {
                Text(it, style = MaterialTheme.typography.bodyMedium)
            }
        }

        Spacer(Modifier.height(10.dp))
        Text(
            "Advice only. Never paste keys, passwords or full configs here. Your question is sent to Google's Gemini service, which is not routed through the VPN tunnel.",
            style = MaterialTheme.typography.bodySmall,
            color = scheme.onSurfaceVariant,
        )
    }
}
