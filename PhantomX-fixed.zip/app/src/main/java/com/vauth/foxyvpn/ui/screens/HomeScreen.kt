package com.vauth.foxyvpn.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.vauth.foxyvpn.ui.PhantomLogo
import com.vauth.foxyvpn.ui.CreatorBadge
import com.vauth.foxyvpn.ui.LogsPreviewCard
import com.vauth.foxyvpn.ui.ToolsCard
import com.vauth.foxyvpn.ui.TrafficChartCard
import com.vauth.foxyvpn.ui.extraTunnelConnected
import com.vauth.foxyvpn.ui.rememberExtraTunnelSampler
import com.vauth.foxyvpn.ui.WarpCard
import com.vauth.foxyvpn.ui.AiAdvisorCard
import com.vauth.foxyvpn.ui.theme.PhantomCyan
import com.vauth.foxyvpn.ui.theme.PhantomInk
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Power
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.vauth.foxyvpn.FoxyVpnApp
import com.vauth.foxyvpn.data.GUARDIAN_ENDPOINT_DEFAULT
import com.vauth.foxyvpn.data.RECOMMENDED_COUNTRY_CODE
import com.vauth.foxyvpn.data.ServerListClient
import com.vauth.foxyvpn.data.formatBytes
import com.vauth.foxyvpn.data.model.ConnectionState
import com.vauth.foxyvpn.data.model.emojiFlag
import com.vauth.foxyvpn.ui.theme.LocalFoxyStatusColors
import com.vauth.foxyvpn.ui.theme.ThemeController
import com.vauth.foxyvpn.ui.theme.ThemeMode
import com.vauth.foxyvpn.vpn.ExitCheck
import com.vauth.foxyvpn.vpn.FoxyVpnService
import com.vauth.foxyvpn.vpn.IpLocationInfo
import com.vauth.foxyvpn.vpn.PingUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    app: FoxyVpnApp,
    themeController: ThemeController,
    onRequestConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onOpenServers: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenLogs: () -> Unit = {},
) {
    val state by FoxyVpnService.state.collectAsState()
    val lastError by FoxyVpnService.lastError.collectAsState()
    val liveStats by FoxyVpnService.vpnLiveStats.collectAsState()
    val connectedAtEpochMs by FoxyVpnService.connectedAtEpochMs.collectAsState()
    val pingLatency by FoxyVpnService.pingLatencyMs.collectAsState()
    val vpnEdgeIp by FoxyVpnService.vpnEdgeIp.collectAsState()

    val selectedProxy by app.proxyStateStore.selectedProxyFlow.collectAsState()

    val statusColors = LocalFoxyStatusColors.current
    val targetRingColor = when (state) {
        ConnectionState.CONNECTED -> statusColors.connected
        ConnectionState.CONNECTING -> statusColors.connecting
        ConnectionState.DISCONNECTED -> MaterialTheme.colorScheme.outline
    }

    val ringColor by animateColorAsState(targetValue = targetRingColor, label = "connect-ring-color")
    val scale by animateFloatAsState(
        targetValue = if (state == ConnectionState.CONNECTED) 1f else 0.92f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "connect-scale",
    )

    val systemInDarkTheme = isSystemInDarkTheme()
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    var realIp by remember {
        mutableStateOf<IpLocationInfo?>(
            app.settingsStore.cachedRealIp?.let {
                IpLocationInfo(it, app.settingsStore.cachedRealCountry.orEmpty())
            },
        )
    }
    var isPinging by remember { mutableStateOf(false) }
    var disconnectedPingLatency by remember { mutableStateOf<Int?>(null) }
    var quotaRemaining by remember { mutableStateOf(app.settingsStore.cachedQuotaRemaining) }
    var quotaMax by remember { mutableStateOf(app.settingsStore.cachedQuotaMax) }
    var isUnlimited by remember { mutableStateOf(app.settingsStore.cachedIsUnlimited) }

    LaunchedEffect(state) {
        if (state == ConnectionState.CONNECTED) {
            quotaRemaining = app.settingsStore.cachedQuotaRemaining
            quotaMax = app.settingsStore.cachedQuotaMax
            isUnlimited = app.settingsStore.cachedIsUnlimited
        }
    }

    LaunchedEffect(state, connectedAtEpochMs) {
        if (state == ConnectionState.CONNECTED && connectedAtEpochMs != null) {
            while (isActive) {
                val now = System.currentTimeMillis()
                elapsedSeconds = ((now - connectedAtEpochMs!!) / 1000L).coerceAtLeast(0L)
                delay(1000L)
            }
        } else {
            elapsedSeconds = 0L
        }
    }

    LaunchedEffect(Unit) {
        launch {
            ExitCheck().fetchDirectIpInfo().onSuccess { info ->
                realIp = info
                app.settingsStore.cachedRealIp = info.ip
                app.settingsStore.cachedRealCountry = info.countryCode
            }
        }
        launch {
            val token = app.authRepository.currentAccessToken()
            if (token != null) {
                runCatching { app.guardianClient.fetchUserInfo(GUARDIAN_ENDPOINT_DEFAULT, token) }
                    .onSuccess { entitlement ->
                        val unlimited = !entitlement.limitedBandwidth
                        isUnlimited = unlimited
                        app.settingsStore.cachedIsUnlimited = unlimited
                        entitlement.quotaRemaining?.let {
                            quotaRemaining = it
                            app.settingsStore.cachedQuotaRemaining = it
                        }
                        entitlement.maxBytes?.let {
                            quotaMax = it
                            app.settingsStore.cachedQuotaMax = it
                        }
                    }
            }
        }
    }

    val infinite = rememberInfiniteTransition(label = "orb")
    val pulse by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2800, easing = LinearEasing), RepeatMode.Restart),
        label = "orb-pulse",
    )
    val isConnected = state == ConnectionState.CONNECTED
    val orbActive = state != ConnectionState.DISCONNECTED
    val scheme = MaterialTheme.colorScheme

    val onPingClick: () -> Unit = {
        if (!isPinging) {
            scope.launch {
                isPinging = true
                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                if (state == ConnectionState.CONNECTED) {
                    FoxyVpnService.pingNow()
                } else {
                    val target = selectedProxy ?: app.proxyStateStore.load() ?: run {
                        val cached = app.serverListClient.loadCachedCountries()
                        ServerListClient.candidatesForCountry(cached, RECOMMENDED_COUNTRY_CODE).firstOrNull()
                            ?: cached.firstOrNull { it.code.isNotBlank() }?.let { country ->
                                ServerListClient.candidatesForCountry(cached, country.code).firstOrNull()
                            }
                    }
                    if (target != null) {
                        disconnectedPingLatency = PingUtil.measureTcpLatencyMs(target.host, target.port)
                    }
                }
                isPinging = false
            }
        }
    }

    val ipDisplay = if (isConnected) {
        vpnEdgeIp?.let { if (it.countryCode.isNotEmpty()) "${it.ip}  ${it.countryCode}" else it.ip } ?: "Checking\u2026"
    } else {
        realIp?.let { if (it.countryCode.isNotEmpty()) "${it.ip}  ${it.countryCode}" else it.ip }
            ?: app.settingsStore.cachedRealIp?.let { cachedIp ->
                val cc = app.settingsStore.cachedRealCountry
                if (!cc.isNullOrEmpty()) "$cachedIp  $cc" else cachedIp
            } ?: "Checking\u2026"
    }
    val currentPing = if (isConnected) pingLatency else disconnectedPingLatency

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(scheme.background, scheme.surfaceContainerLowest))),
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .widthIn(max = 520.dp)
                .fillMaxSize()
                .systemBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    PhantomLogo(size = 36.dp)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "Phantom X",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp,
                        ),
                    )
                }
                val mode = themeController.mode
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .combinedClickable(
                            role = Role.Button,
                            onClick = { themeController.toggle(systemInDarkTheme) },
                            onLongClick = {
                                haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                                themeController.set(ThemeMode.SYSTEM)
                            },
                        ),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = when (mode) {
                            ThemeMode.SYSTEM -> Icons.Filled.BrightnessAuto
                            ThemeMode.LIGHT -> Icons.Filled.LightMode
                            ThemeMode.DARK -> Icons.Filled.DarkMode
                        },
                        contentDescription = "Change theme. Long press to follow the system",
                        tint = scheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = scheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(12.dp))

            Box(modifier = Modifier.size(300.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val c = center
                    val base = size.minDimension / 2f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(ringColor.copy(alpha = if (orbActive) 0.34f else 0.10f), Color.Transparent),
                            center = c,
                            radius = base,
                        ),
                        radius = base,
                        center = c,
                    )
                    if (orbActive) {
                        for (i in 0 until 3) {
                            val p = (pulse + i / 3f) % 1f
                            drawCircle(
                                color = ringColor.copy(alpha = (1f - p) * 0.40f),
                                radius = base * (0.52f + 0.48f * p),
                                center = c,
                                style = Stroke(width = 2.dp.toPx()),
                            )
                        }
                    }
                }
                Box(
                    modifier = Modifier
                        .size((156 * scale).dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(PhantomInk, ringColor.copy(alpha = 0.55f))))
                        .border(2.dp, ringColor, CircleShape)
                        .clickable(role = Role.Button) {
                            if (state == ConnectionState.DISCONNECTED) onRequestConnect() else onDisconnect()
                        },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        imageVector = Icons.Filled.Power,
                        contentDescription = if (state == ConnectionState.DISCONNECTED) "Connect" else "Disconnect",
                        tint = Color.White,
                        modifier = Modifier.size(60.dp),
                    )
                }
            }

            Text(
                text = when (state) {
                    ConnectionState.CONNECTED -> "You\u2019re protected"
                    ConnectionState.CONNECTING -> "Connecting\u2026"
                    ConnectionState.DISCONNECTED -> "Not protected"
                },
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = when (state) {
                    ConnectionState.CONNECTING -> "Tap the button to cancel"
                    ConnectionState.CONNECTED -> formatDuration(elapsedSeconds)
                    ConnectionState.DISCONNECTED -> "Tap the button to connect"
                },
                style = MaterialTheme.typography.bodyMedium.copy(fontFeatureSettings = "tnum"),
                color = scheme.onSurfaceVariant,
            )

            val error = lastError
            if (error != null && state != ConnectionState.CONNECTING) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = error,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodySmall,
                    color = scheme.error,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
            }

            Spacer(Modifier.height(20.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(scheme.surfaceContainerHigh)
                    .clickable(role = Role.Button, onClick = onOpenServers)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val flag = selectedProxy?.emojiFlag
                if (!flag.isNullOrBlank()) {
                    Text(flag, style = MaterialTheme.typography.titleLarge)
                } else {
                    Icon(Icons.Filled.Public, contentDescription = null, tint = scheme.primary)
                }
                Spacer(Modifier.width(12.dp))
                Text(
                    selectedProxy?.let { it.countryName.ifBlank { it.countryCode } } ?: "Recommended location",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                Text("Change", style = MaterialTheme.typography.labelLarge, color = scheme.primary)
                Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = scheme.primary)
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(scheme.surfaceContainer)
                    .padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(1f)) {
                    Text("IP address", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
                    Spacer(Modifier.height(2.dp))
                    Text(
                        ipDisplay,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                    )
                }
                val badge = if (isConnected) statusColors.connected else scheme.error
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(badge.copy(alpha = 0.16f))
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                ) {
                    Text(
                        if (isConnected) "Hidden" else "Visible",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = badge,
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    "Download",
                    if (isConnected) "${formatBytes(liveStats.rxRateBytesPerSec)}/s" else "\u2014",
                    Modifier.weight(1f),
                    icon = Icons.Filled.ArrowDownward,
                )
                StatTile(
                    "Upload",
                    if (isConnected) "${formatBytes(liveStats.txRateBytesPerSec)}/s" else "\u2014",
                    Modifier.weight(1f),
                    icon = Icons.Filled.ArrowUpward,
                )
            }

            val extraConnected = extraTunnelConnected()
            val extraSampler = rememberExtraTunnelSampler()
            val mainStats by rememberUpdatedState(liveStats)
            if (isConnected || extraConnected) {
                Spacer(Modifier.height(12.dp))
                TrafficChartCard(
                    sample = if (extraConnected) extraSampler
                    else ({ mainStats.rxRateBytesPerSec to mainStats.txRateBytesPerSec }),
                    resetKey = extraConnected,
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(
                    "Latency",
                    when {
                        isPinging -> "Pinging\u2026"
                        currentPing != null -> "$currentPing ms"
                        else -> "\u2014 ms"
                    },
                    Modifier.weight(1f),
                    valueColor = if (currentPing != null) statusColors.connected else scheme.onSurface,
                    onClick = onPingClick,
                )
                StatTile(
                    "This session",
                    if (isConnected) formatBytes(liveStats.sessionBytes) else "0.0 MB",
                    Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(12.dp))

            val remaining = quotaRemaining
            val max = quotaMax
            val quotaFraction = when {
                isUnlimited -> 1f
                max != null && max > 0L && remaining != null -> (remaining.toFloat() / max.toFloat()).coerceIn(0f, 1f)
                else -> 0f
            }
            val quotaText = when {
                isUnlimited -> "Unlimited"
                remaining != null && max != null -> "${formatBytes(remaining)} of ${formatBytes(max)} left"
                remaining != null -> "${formatBytes(remaining)} left"
                max != null -> "Limited to ${formatBytes(max)}"
                else -> "\u2014"
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(scheme.surfaceContainer)
                    .padding(18.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Monthly data",
                        style = MaterialTheme.typography.labelMedium,
                        color = scheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    Text(quotaText, style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold))
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { quotaFraction },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (isConnected) PhantomCyan else scheme.primary,
                    trackColor = scheme.surfaceContainerHighest,
                )
            }

            Spacer(Modifier.height(12.dp))
            ToolsCard(app = app, state = state)
            Spacer(Modifier.height(12.dp))
            WarpCard()
            AiAdvisorCard()
            LogsPreviewCard(onOpenAll = onOpenLogs)

            Spacer(Modifier.height(20.dp))
            CreatorBadge()
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun StatTile(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    valueColor: Color = MaterialTheme.colorScheme.onSurface,
    icon: ImageVector? = null,
    onClick: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .then(if (onClick != null) Modifier.clickable(role = Role.Button, onClick = onClick) else Modifier)
            .padding(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
            }
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = valueColor,
        )
    }
}

private fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
}
