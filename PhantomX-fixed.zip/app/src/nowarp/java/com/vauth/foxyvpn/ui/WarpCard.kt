package com.vauth.foxyvpn.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Placeholder used by the standard build. The WARP build replaces it with the real card. */
@Composable
fun WarpCard(modifier: Modifier = Modifier) {
}
