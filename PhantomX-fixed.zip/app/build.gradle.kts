plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
}

fun buildSecret(name: String): String =
    ((System.getenv(name) ?: (project.findProperty(name) as String?)) ?: "")
        .replace("\\", "\\\\").replace("\"", "\\\"")

val hevSocks5TunnelVersion = "2.17.1"
val hevSocks5TunnelDir = file("src/main/jni")

val fetchHevSocks5Tunnel = tasks.register<Exec>("fetchHevSocks5Tunnel") {
    val marker = File(hevSocks5TunnelDir, "Android.mk")
    outputs.file(marker)
    onlyIf { !marker.exists() }
    doFirst { hevSocks5TunnelDir.mkdirs() }
    commandLine(
        "git", "clone",
        "--branch", hevSocks5TunnelVersion,
        "--depth", "1",
        "--recursive",
        "--shallow-submodules",
        "https://github.com/heiher/hev-socks5-tunnel.git",
        hevSocks5TunnelDir.absolutePath,
    )
}

tasks.matching { it.name.startsWith("externalNativeBuild") || it.name.contains("NdkBuild") }
    .configureEach { dependsOn(fetchHevSocks5Tunnel) }
tasks.named("preBuild").configure { dependsOn(fetchHevSocks5Tunnel) }

val releaseKeystoreFile = rootProject.file("release-keystore.jks")
val releaseKeyAlias: String? = System.getenv("SIGNING_KEY_ALIAS")
val releaseKeyPassword: String? = System.getenv("SIGNING_KEY_PASSWORD")
val releaseStorePassword: String? = System.getenv("SIGNING_STORE_PASSWORD")
val hasReleaseSigning = releaseKeystoreFile.exists() &&
    !releaseKeyAlias.isNullOrBlank() &&
    !releaseKeyPassword.isNullOrBlank() &&
    !releaseStorePassword.isNullOrBlank()

val withWarp = project.hasProperty("withWarp")

// ---- sing-box core (Shadowsocks, Hysteria2, TUIC, Trojan, VLESS/Reality, VMess) -----------------------------------
// Built from the official source at build time into app/src/warp/jniLibs/<abi>/libsingbox.so for the WARP build.
// Needs Go 1.23.1 or newer on the build machine (GitHub's ubuntu runners have it; newer Go downloads the exact
// toolchain by itself).
val singBoxVersion = "v1.11.4"
val singBoxTags = "with_quic,with_utls,with_grpc"
val singBoxSrcDir = layout.buildDirectory.dir("singbox-src").get().asFile
val singBoxJniDir = file("src/warp/jniLibs")
// ABI -> (GOARCH, GOARM)
val singBoxAbis = mapOf(
    "arm64-v8a" to ("arm64" to ""),
    "armeabi-v7a" to ("arm" to "7"),
    "x86_64" to ("amd64" to ""),
    "x86" to ("386" to ""),
)

fun runChecked(dir: File, env: Map<String, String>, vararg cmd: String) {
    val pb = ProcessBuilder(*cmd).directory(dir).inheritIO()
    pb.environment().putAll(env)
    val code = try {
        pb.start().waitFor()
    } catch (e: java.io.IOException) {
        throw GradleException("Could not run '${cmd.first()}'. The sing-box core needs it installed (Go 1.23.1 or newer, and git).", e)
    }
    if (code != 0) throw GradleException("'${cmd.joinToString(" ")}' failed with exit code $code")
}

val buildSingBox = tasks.register("buildSingBox") {
    onlyIf { withWarp }
    outputs.dir(singBoxJniDir)
    outputs.upToDateWhen { singBoxAbis.keys.all { File(singBoxJniDir, "$it/libsingbox.so").exists() } }
    doLast {
        if (singBoxAbis.keys.all { File(singBoxJniDir, "$it/libsingbox.so").exists() }) return@doLast
        if (!File(singBoxSrcDir, "go.mod").exists()) {
            singBoxSrcDir.parentFile.mkdirs()
            runChecked(
                singBoxSrcDir.parentFile, emptyMap(),
                "git", "clone", "--branch", singBoxVersion, "--depth", "1",
                "https://github.com/SagerNet/sing-box.git", singBoxSrcDir.absolutePath,
            )
        }
        for ((abi, arch) in singBoxAbis) {
            val out = File(singBoxJniDir, "$abi/libsingbox.so")
            if (out.exists()) continue
            out.parentFile.mkdirs()
            val env = mutableMapOf(
                "CGO_ENABLED" to "0",
                "GOOS" to "linux",
                "GOARCH" to arch.first,
                "GOTOOLCHAIN" to "auto",
            )
            if (arch.second.isNotEmpty()) env["GOARM"] = arch.second
            runChecked(
                singBoxSrcDir, env,
                "go", "build", "-trimpath", "-tags", singBoxTags,
                "-ldflags", "-X github.com/sagernet/sing-box/constant.Version=${singBoxVersion.removePrefix("v")} -s -w -buildid=",
                "-o", out.absolutePath, "./cmd/sing-box",
            )
        }
    }
}
if (withWarp) tasks.named("preBuild").configure { dependsOn(buildSingBox) }


android {
    namespace = "com.vauth.foxyvpn"

    sourceSets {
        getByName("main") {
            java.srcDir(if (withWarp) "src/warp/java" else "src/nowarp/java")
            if (withWarp) jniLibs.srcDir("src/warp/jniLibs")
        }
        if (withWarp) {
            getByName("debug").manifest.srcFile("src/warp/AndroidManifest.xml")
            getByName("release").manifest.srcFile("src/warp/AndroidManifest.xml")
        }
    }

    compileSdk = 35

    ndkVersion = "26.1.10909125"

    defaultConfig {
        applicationId = "com.alireza.phantomx"
        minSdk = 26
        targetSdk = 35
        versionCode = 51
        versionName = "1.1.5"

        buildConfigField("String", "DEFAULT_EMAIL", "\"${buildSecret("PHANTOM_EMAIL")}\"")
        buildConfigField("String", "DEFAULT_PASSWORD", "\"${buildSecret("PHANTOM_PASSWORD")}\"")
        buildConfigField("String", "GEMINI_API_KEY", "\"${buildSecret("GEMINI_API_KEY")}\"")

        externalNativeBuild {
            ndkBuild {
                abiFilters += listOf("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
                arguments += listOf(

                    "APP_PLATFORM=android-26",

                    "APP_CFLAGS=-DPKGNAME=com/vauth/foxyvpn/vpn/tun -DCLSNAME=HevSocks5Tunnel",
                )
            }
        }
    }

    externalNativeBuild {
        ndkBuild {
            path = file("src/main/jni/Android.mk")
        }
    }

    signingConfigs {
        if (hasReleaseSigning) {
            create("release") {
                storeFile = releaseKeystoreFile
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = withWarp
    }

    kotlinOptions {
        jvmTarget = "17"
        freeCompilerArgs += listOf(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3ExpressiveApi",
        )
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        // The WARP build ships the sing-box core as libsingbox.so and runs it from nativeLibraryDir.
        if (withWarp) jniLibs.useLegacyPackaging = true
        resources.excludes.add("META-INF/INDEX.LIST")
        resources.excludes.add("META-INF/*.SF")
        resources.excludes.add("META-INF/*.DSA")
        resources.excludes.add("META-INF/*.RSA")
        resources.pickFirsts.add("META-INF/io.netty.versions.properties")
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.01.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3:1.4.0-alpha10")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.navigation:navigation-compose:2.8.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.core:core-ktx:1.15.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")

    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    implementation("io.netty:netty-handler:4.1.115.Final")
    implementation("io.netty:netty-codec-http2:4.1.115.Final")
    implementation("io.netty:netty-transport:4.1.115.Final")

    implementation("io.netty:netty-handler-proxy:4.1.115.Final")

    implementation("org.conscrypt:conscrypt-android:2.5.2")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    debugImplementation("androidx.compose.ui:ui-tooling")

    if (withWarp) {
        implementation("com.wireguard.android:tunnel:1.0.20230706")
        // Pure-Java QR decoder used to import WireGuard configs from a screenshot (no camera, no Google services).
        implementation("com.google.zxing:core:3.5.3")
        add("coreLibraryDesugaring", "com.android.tools:desugar_jdk_libs:2.0.4")
    }
}
