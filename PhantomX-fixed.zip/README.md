# Phantom X

Phantom X is a VPN client for Android with a redesigned Jetpack Compose interface.
Created by **Alireza Moghyasi**.

It is a fork of [FoxyVPN](https://github.com/Vauth/FoxyVPN) by Vauth, used under the MIT license.
The original copyright notice stays in `LICENSE`.

## Build the APK on GitHub

1. Create a **private** repository and upload this project.
2. Open **Settings > Secrets and variables > Actions** and add two secrets:
   `PHANTOM_EMAIL` and `PHANTOM_PASSWORD` (your Firefox account). Leave them out to show the normal sign-in screen.
3. Open **Actions > Phantom X build > Run workflow**.
4. When it finishes, download `phantomx-debug-apk` from the run page and install the APK.

On first launch the app shows a welcome screen (Persian) with two options: continue with the default account
(only shown when the two secrets exist) or sign in with your own Firefox account, with a short guide to create one.

The credentials are read at build time and are not stored in the source code.
Anyone who receives the APK can extract them, so keep the build for your own use.

## Features added in this version

- Creator badge on the home and welcome screens.
- **Tools** card on the home screen: tunnel speed test, "Fastest server" search and one-tap copy of the exit IP.
- **Recent logs** section on the home screen with copy-all and a shortcut to the full log screen.
- Settings > **Bypass Iranian apps** (on by default): banking, payment, taxi, shopping and other Iranian apps skip the VPN automatically.
- Settings > **Fast IPv6 fallback** (on by default): apps such as Telegram skip IPv6 immediately instead of waiting for a timeout.
- Stability work: faster dead-link detection, a single 403 no longer takes the whole tunnel down, one retry for streams that die while opening, longer idle timeout for long-lived connections.

See `CHANGELOG.md` for details.

## Extra tunnels (WARP build)

The standard build is unchanged. A second build adds an **Extra tunnels** card on the home screen:
free Cloudflare WARP (account created automatically, several endpoints tried in turn) and a field
for your own WireGuard config. Build it with `./gradlew assembleDebug -PwithWarp=true`.
Only one VPN can run at a time, so connecting WARP replaces the Phantom X VPN until you reconnect it.

### More protocols in the WARP build

The same **Extra tunnels** card also connects **Shadowsocks, Hysteria2, TUIC, Trojan, VLESS (incl. Reality) and VMess**:
paste a share link (`ss://`, `hysteria2://`, `trojan://`, `vless://`, `vmess://`, `tuic://`) and tap Connect.
They run on a [sing-box](https://github.com/SagerNet/sing-box) core (v1.11.4, built from source by Gradle into `app/src/warp/jniLibs` during the build; needs Go 1.23.1+)
behind the existing packet forwarder. Hysteria2/TUIC use BBR by default. WARP and your own WireGuard config work as before.
These protocols need a server; the app cannot provide one. The standard build is unchanged.

### WireGuard (WARP build)

The **WireGuard** section of the Extra tunnels card is a complete client built on the official wireguard-go backend:

- **Profiles**: any number, stored encrypted. Import a `.conf` file, paste a config or a `wireguard://` link from the clipboard,
  or pick a screenshot with a QR code. Options that Android cannot use (`PostUp`, `Table`, ...) are dropped automatically.
- **Keys**: shows your public key, generates a new key pair (or a whole new profile), adds/replaces/removes a preshared key,
  reveals or copies the private key on request. Export writes a `.conf` file.
- **Status**: endpoint, connected time, last handshake, totals and live speed, plus a notification with a Disconnect button.
- **Auto troubleshooting**: checks the config and the network before connecting, tries the last working endpoint, the other IPs
  of the server name and your fallback endpoints (for example port 443), waits for a real handshake, then checks IP, DNS and a TLS
  fetch through the tunnel and lowers the MTU to 1280 when large packets are lost. While connected it reconnects by itself when the
  tunnel stops answering or the phone switches between Wi-Fi and mobile data. The **Run** / **Copy report** buttons give a readable
  report without any key in it.
- Optional per profile: keepalive 25 s when the config has none, and letting Iranian apps skip the tunnel.

The standard build is unchanged. The WARP build and the WireGuard section share one WireGuard engine, so connecting one replaces the other
(only one VPN can run on Android).

## Publish on GitHub

1. Create a repository and upload every file in this folder, including the hidden `.github` folder.
2. The Gradle build downloads the native tunnel library ([hev-socks5-tunnel](https://github.com/heiher/hev-socks5-tunnel), version 2.17.1) by itself with `git` the first time it builds, so nothing has to be added to `app/src/main/jni`.
3. Open **Actions > Phantom X build > Run workflow** to get a debug APK (`phantomx-debug-apk`).
4. To publish a release, push a tag such as `v1.1.3`. The workflow builds the APK and attaches it to a GitHub Release.
   - With the secrets `SIGNING_KEYSTORE_BASE64`, `SIGNING_KEY_ALIAS`, `SIGNING_KEY_PASSWORD`, `SIGNING_STORE_PASSWORD` it builds a signed release APK.
   - Without them it attaches an installable debug-signed APK instead.
   - Release builds never include `PHANTOM_EMAIL` / `PHANTOM_PASSWORD`, so a public release does not leak the default account.
